package com.sena.restTutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
